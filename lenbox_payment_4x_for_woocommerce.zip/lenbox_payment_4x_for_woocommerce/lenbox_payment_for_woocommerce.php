<?php

/**
 * Plugin Name:       Lenbox Paiement 4x
 * Plugin URI:        https://github.com/codaid
 * Description:       Offrez le paiement en 4x grace a Lenbox.
 * Version:           1.0.0
 * Author:            Codaid
 * Author URI:        http://codaid.com/
 * License:           Private
 * License URI:       http://codaid.com/
 * Text Domain:       codaid-lenbox-woo
 * Requires at least: 5.3
 * Requires PHP: 7.0
 * Tested up to: 5.8.2
 * WC requires at least: 3.0.0
 * WC tested up to: 6.0.0
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
	return;
}

add_action('plugins_loaded', 'lenbox_payment_4x_init', 11);
add_filter('woocommerce_payment_gateways', 'add_to_woo_lenbox_payment_4x_gateway');

function lenbox_payment_4x_init()
{
	if (class_exists('WC_Payment_Gateway')) {
		require_once plugin_dir_path(__FILE__) . '/includes/class-wc-payment-4x-gateway-lenbox.php';
		require_once plugin_dir_path(__FILE__) . '/includes/lenbox-order-statuses.php';
		require_once plugin_dir_path(__FILE__) . '/includes/lenbox-4x-add-description-price.php';
		require_once plugin_dir_path(__FILE__) . '/includes/codaid-lenbox-webhook.php';
	}
}

function add_to_woo_lenbox_payment_4x_gateway($gateways)
{
	$gateways[] = 'WC_Gateway_Lenbox_4x';
	return $gateways;
}
